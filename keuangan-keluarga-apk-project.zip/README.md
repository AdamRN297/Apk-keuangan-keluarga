# Keuangan Keluarga: cara membuat APK

Proyek ini sudah siap dibungkus jadi aplikasi Android dengan Capacitor.
Pilih salah satu cara.

## Cara A: tanpa install apa-apa (lewat GitHub, gratis)

1. Buat akun di github.com, lalu buat repository baru (boleh Private).
2. Unggah semua isi folder ini ke repository tersebut.
   Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
   Kalau folder `.github` tidak ikut, klik Add file > Create new file,
   ketik nama `.github/workflows/build-apk.yml`, lalu tempel isi file `build-apk.yml`.
3. Buka tab Actions > Build APK > Run workflow. Tunggu sekitar 5 sampai 10 menit.
4. Buka hasil build yang selesai, unduh `keuangan-keluarga-apk` di bagian Artifacts.
   Ekstrak zip-nya, di dalamnya ada `app-debug.apk`.
5. Kirim file APK ke HP, buka, lalu izinkan "Instal dari sumber tidak dikenal".

## Cara B: di laptop (Windows, Mac, atau Linux)

Butuh: Node.js 20 ke atas dan Android Studio.

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

Di Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
Hasilnya ada di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Catatan

- Data tersimpan di dalam aplikasi di HP tersebut. Gunakan Pengaturan > Cadangan data secara berkala.
- Font Sora dimuat dari internet. Tanpa koneksi, aplikasi memakai font bawaan HP.
- APK ini bertanda tangan debug, cukup untuk dipakai pribadi.
  Untuk Google Play Store perlu build rilis dengan keystore sendiri.
- Untuk mengubah tampilan atau fitur, edit `www/index.html`, lalu jalankan ulang build.
